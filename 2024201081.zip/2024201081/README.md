Lab Assignment 1 : Malay Damani - Roll No. : 2024201081

There are two shell files present in the repository, 

2024201081_q1.sh and 2024201081_q2.sh

Along with example files access.log and power_levels.txt, which provide data for our shell files. 

2024201081_q1 can be run with command ./2024201081_q1.sh
Similarly, 2024201081_q2 can be run with command ./2024201081_q2.sh

# 2024201081_q1
The task was to write a bash script to extract all lines from access.log where the request method is POST
and the HTTP status code is 404.

## Expected access.log file
127.0.0.1 - - [08/Aug/2024:14:55:02 +0000] "GET /index.html HTTP/1.1" 200 1043
127.0.0.1 - - [08/Aug/2024:14:55:03 +0000] "POST /login HTTP/1.1" 200 512
127.0.0.1 - - [08/Aug/2024:14:55:05 +0000] "POST /submit HTTP/1.1" 404 1024
127.0.0.1 - - [08/Aug/2024:14:55:06 +0000] "GET /about.html HTTP/1.1" 404 2048
127.0.0.1 - - [08/Aug/2024:14:55:08 +0000] "POST /upload HTTP/1.1" 404 512
127.0.0.1 - - [08/Aug/2024:14:55:10 +0000] "POST /data HTTP/1.1" 200 256
127.0.0.1 - - [08/Aug/2024:14:55:12 +0000] "GET /home HTTP/1.1" 500 1024
127.0.0.1 - - [08/Aug/2024:14:55:14 +0000] "POST /edit HTTP/1.1" 404 768
127.0.0.1 - - [08/Aug/2024:14:55:16 +0000] "GET /contact HTTP/1.1" 200 2048

## Expected Output

127.0.0.1 - - [08/Aug/2024:14:55:05 +0000] "POST /submit HTTP/1.1" 404 1024
127.0.0.1 - - [08/Aug/2024:14:55:08 +0000] "POST /upload HTTP/1.1" 404 512
127.0.0.1 - - [08/Aug/2024:14:55:14 +0000] "POST /edit HTTP/1.1" 404 768


# 2024201081_q2
The task was to write a bash script to calculate the total power level of all the seniors in power_levels.txt. 

## Expected power_levels.txt file
101,Goku,DBZ,88000
102,Saitama,One Punch Man,83000
103,Gojo,JJK,57000
104,Luffy,One Piece,64000
105,Ichigo,Bleach,43000

## Expected Output: 
335000
